$(function() {
	//----- OPEN
	$('[data-popup-open]').on('click', function(e)  {
		var targeted_popup_class = jQuery(this).attr('data-popup-open');
		$('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
		e.preventDefault();
	});
	//----- CLOSE
	$('[data-popup-close]').on('click', function(e)  {
		var targeted_popup_class = jQuery(this).attr('data-popup-close');
		$('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
		e.preventDefault();
	});
});

///////	
function burn1() {
    letras1.play();	
}
function burn2() {
   letras2.play();	  
}
function burn3() {
    letras3.play();
}
function burn4() {
    letras4.play();
}
function burn5() {
    letras5.play();
}
function burn6() {
    letras6.play();
}
function burn7() {
   letras7.play();
}
function burn8() {
    letras8.play();
}
function burn9() {
    letras9.play();
}
function burn10() {
    letras10.play();
}
function burn11() {
    letras11.play();
}
function burn12() {
   letras12.play();
}
function burn13() {
    letras13.play();
}
function burn14() {
    letras14.play();
}
function burn15() {
    letras15.play();
}
function burn16() {
    letras16.play();
}
function burn17() {
   letras17.play();
}
function burn18() {
    letras18.play();
}
function burn19() {
    letras19.play();
}
function burn20() {
    letras20.play();
}		
function burn21() {
    letras21.play();
}
function burn22() {
   letras22.play();
}
function burn23() {
    letras23.play();
}
function burn24() {
    letras24.play();
}
function burn25() {
    letras25.play();
}
function burn26() {
    letras26.play();
}		

/// anular botones
function anular() {
		document.getElementById('audioA').onclick = null;
		document.getElementById('audioB').onclick = null;
	   document.getElementById('audioC').onclick = null;
	   document.getElementById('audioD').onclick = null;
	   document.getElementById('audioE').onclick = null;
	   document.getElementById('audioF').onclick = null;
	   document.getElementById('audioG').onclick = null;
	   document.getElementById('audioH').onclick = null;
	   document.getElementById('audioI').onclick = null;
	   document.getElementById('audioJ').onclick = null;
	   document.getElementById('audioK').onclick = null;
	   document.getElementById('audioL').onclick = null;
	   document.getElementById('audioM').onclick = null;
	   document.getElementById('audioN').onclick = null;
	   document.getElementById('audioO').onclick = null;
	   document.getElementById('audioP').onclick = null;
	   document.getElementById('audioQ').onclick = null;
	   document.getElementById('audioR').onclick = null;
	   document.getElementById('audioS').onclick = null;
	   document.getElementById('audioT').onclick = null;
	   document.getElementById('audioU').onclick = null;
	   document.getElementById('audioV').onclick = null;
	   document.getElementById('audioW').onclick = null;
	   document.getElementById('audioX').onclick = null;
	   document.getElementById('audioY').onclick = null;
	   document.getElementById('audioZ').onclick = null;
	}

function showAlert() {
        alert("Oh you wrong!");
		audioID0.play();
      }

function random() {	
    var rand = Math.floor(Math.random() * (26 - 1)) + 1;
	var a1 = document.getElementById("audioA").onclick;
	var a2 = document.getElementById("letras1").onplay;
	var b1 = document.getElementById("audioB").onclick;
	var b2 = document.getElementById("letras2").onplay;
	var c1 = document.getElementById("audioC").onclick;
	var c2 = document.getElementById("letras3").onplay;
	var d1 = document.getElementById("audioD").onclick;
	var d2 = document.getElementById("letras4").onplay;
	var e1 = document.getElementById("audioE").onclick;
	var e2 = document.getElementById("letras5").onplay;
	var f1 = document.getElementById("audioF").onclick;
	var f2 = document.getElementById("letras6").onplay;
	var g1 = document.getElementById("audioG").onclick;
	var g2 = document.getElementById("letras7").onplay;
	var h1 = document.getElementById("audioH").onclick;
	var h2 = document.getElementById("letras8").onplay;
	var i1 = document.getElementById("audioI").onclick;
	var i2 = document.getElementById("letras9").onplay;
	var j1 = document.getElementById("audioJ").onclick;
	var j2 = document.getElementById("letras10").onplay;
	var k1 = document.getElementById("audioK").onclick;
	var k2 = document.getElementById("letras11").onplay;
	var l1 = document.getElementById("audioL").onclick;
	var l2 = document.getElementById("letras12").onplay;
	var m1 = document.getElementById("audioM").onclick;
	var m2 = document.getElementById("letras13").onplay;
	var n1 = document.getElementById("audioN").onclick;
	var n2 = document.getElementById("letras14").onplay;
	var o1 = document.getElementById("audioO").onclick;
	var o2 = document.getElementById("letras15").onplay;
	var p1 = document.getElementById("audioP").onclick;
	var p2 = document.getElementById("letras16").onplay;
	var q1 = document.getElementById("audioQ").onclick;
	var q2 = document.getElementById("letras17").onplay;
	var r1 = document.getElementById("audioR").onclick;
	var r2 = document.getElementById("letras18").onplay;
	var s1 = document.getElementById("audioS").onclick;
	var s2 = document.getElementById("letras19").onplay;
	var t1 = document.getElementById("audioT").onclick;
	var t2 = document.getElementById("letras20").onplay;
	var u1 = document.getElementById("audioU").onclick;
	var u2 = document.getElementById("letras21").onplay;
	var v1 = document.getElementById("audioV").onclick;
	var v2 = document.getElementById("letras22").onplay;
	var w1 = document.getElementById("audioW").onclick;
	var w2 = document.getElementById("letras23").onplay;
	var x1 = document.getElementById("audioX").onclick;
	var x2 = document.getElementById("letras24").onplay;
	var y1 = document.getElementById("audioY").onclick;
	var y2 = document.getElementById("letras25").onplay;
	var z1 = document.getElementById("audioZ").onclick;
	var z2 = document.getElementById("letras26").onplay;
	
    switch(rand) {
case 1:
            burn1();	
			document.getElementById('audioA').onclick = function(){
   if (a1 === a2) {
  			document.getElementById('popupA').style.display = 'block'; // show
	 	anular();
			audioIDA1.play();   
   } else if (a1 !== a2)  {
	showAlert();	   
   }
};
			break;
case 2:
            burn2();
			document.getElementById('audioB').onclick = function(){
   if (b1 === b2) {
  			document.getElementById('popupB').style.display = 'block'; // show
			audioIDB1.play();  
	   anular();
   } else if (b1 !== b2){	   
	   showAlert();
   }
};
            break;
case 3:
            burn3();
			document.getElementById('audioC').onclick = function(){
   if (c1 === c2) {
  			document.getElementById('popupC').style.display = 'block'; // show
			audioIDC1.play(); 
	   anular();
   } else if (c1 !== c2) {
	showAlert();
   }
};
            break;
case 4:
            burn4();
			document.getElementById('audioD').onclick = function(){
   if (d1 === d2) {
  			document.getElementById('popupD').style.display = 'block'; // show
			audioIDD1.play();  
	   anular();
    } else if (d1 !== d2) {
	showAlert();
   }
};
            break;
case 5:
            burn5();
			document.getElementById('audioE').onclick = function(){
   if (e1 === e2) {
  			document.getElementById('popupE').style.display = 'block'; // show
			audioIDE1.play(); 
	   anular();
   } else if (e1 !== e2) {
	showAlert();
	   
   }
};
            break;
case 6:
            burn6();
			document.getElementById('audioF').onclick = function(){
   if (f1 === f2) {
  			document.getElementById('popupF').style.display = 'block'; // show
			audioIDF1.play();   
	    anular();
   } else if (f1 !== f2) {
	showAlert();	 
   }
};
            break;
case 7:
            burn7();
			document.getElementById('audioG').onclick = function(){
   if (g1 === g2) {
  			document.getElementById('popupG').style.display = 'block'; // show
			audioIDG1.play(); 
	   anular();
   } else if (g1 !== g2) {
	showAlert();	   
   }
};
            break;
case 8:
            burn8();
			document.getElementById('audioH').onclick = function(){
   if (h1 === h2) {
  		document.getElementById('popupH').style.display = 'block'; // show
			audioIDH1.play();
	   anular();	
   } else if (h1 !== h2) {	
	showAlert();
	
   }
}; 
			break;
case 9:
            burn9();
			document.getElementById('audioI').onclick = function(){
   if (i1 === i2) {
  			document.getElementById('popupI').style.display = 'block'; // show
			audioIDI1.play();  
	   anular();
   } else if (i1 !== i2) {
	audioID0.play(); 
   }
};
            break;
 case 10:
            burn10();
			document.getElementById('audioJ').onclick = function(){
   if (j1 === j2) {
  			document.getElementById('popupJ').style.display = 'block'; // show
			audioIDJ1.play(); 
	   anular();
   } else if (j1 !== j2){
	showAlert();
   }
};
            break;
case 11:
            burn11();
			document.getElementById('audioK').onclick = function(){
   if (k1 === k2) {
  			document.getElementById('popupK').style.display = 'block'; // show
			audioIDK1.play(); 
	   anular();
   } else if (k1 !== k2){
	showAlert();
   }
};
            break;
case 12:
            burn12();
			document.getElementById('audioL').onclick = function(){
   if (l1 === l2) {
  			document.getElementById('popupL').style.display = 'block'; // show
			audioIDL1.play(); 
	   anular();
   } else if (l1 !== l2){
	showAlert();
   }
};
            break;
case 13:
            burn13();
			document.getElementById('audioM').onclick = function(){
   if (m1 === m2) {
  			document.getElementById('popupM').style.display = 'block'; // show
			audioM1.play(); 
	   anular();
   } else {
	showAlert();
   }
};
            break;
case 14:
            burn14();
			document.getElementById('audioN').onclick = function(){
   if (n1 === n2) {
  			document.getElementById('popupN').style.display = 'block'; // show
			audioIDN1.play();
	   anular();
   } else if (n1 !== n2){
	showAlert();   
   }
};
            break;
case 15:
            burn15();
			document.getElementById('audioO').onclick = function(){
   if (o1 === o2) {
  			document.getElementById('popupO').style.display = 'block'; // show
			audioIDO1.play();
	   anular();
   } else if (o1 !== o2) {
	showAlert();
   }
};
            break;
case 16:
            burn16();
			document.getElementById('audioP').onclick = function(){
   if (p1 === p2) {
  			document.getElementById('popupP').style.display = 'block'; // show
			audioIDP1.play();  
	   anular();
   } else if (p1 !== p2){
	showAlert();
   }
};
            break;
case 17:
            burn17();
			document.getElementById('audioQ').onclick = function(){
   if (q1 === q2) {
  		document.getElementById('popupQ').style.display = 'block'; // show
		audioIDQ1.play(); 
	   anular();
	   
   }  else {
	alert("Oh you wrong!");
		audioID0.play();
   }
};
            break;
case 18:
            burn18();
			document.getElementById('audioR').onclick = function(){
   if (r1 === r2) {
  			document.getElementById('popupR').style.display = 'block'; // show
			audioIDR1.play();  
	   anular();
   } else {
	showAlert();
   }
};
            break;
case 19:
            burn19();
			
			document.getElementById('audioS').onclick = function(){
   if (s1 === s2) {
  			document.getElementById('popupS').style.display = 'block'; // show
			audioIDS1.play();  
	   anular();
   } else if (s1 !== s2){
	showAlert();	   
   }
};
            break;
case 20:
            burn20();
			document.getElementById('audioT').onclick = function(){
   if (t1 === t2) {
  			document.getElementById('popupT').style.display = 'block'; // show
			audioIDT1.play(); 
	   anular();
   } else if (t1 !== t2){
	showAlert();
   }
};
            break;
case 21:
            burn21();
			document.getElementById('audioU').onclick = function(){
   if (u1 == u2) {
  		document.getElementById('popupU').style.display = 'block'; // show
			audioIDU1.play();  
	   anular();	
   } else if (u1 != u2){
	showAlert();	
   }
};
            break;
case 22:
            burn22();
			document.getElementById('audioV').onclick = function(){
   if (v1 === v2) {
  			document.getElementById('popupV').style.display = 'block'; // show
			audioIDV1.play();
	   anular();
   } else if (v1 !== v2){
	showAlert();
   }
};
            break;
case 23:
            burn23();
			document.getElementById('audioW').onclick = function(){
   if (w1 === w2) {
  			document.getElementById('popupW').style.display = 'block'; // show
			audioIDW1.play();			
	   anular();	   
   }else if (w1 !== w2){
	showAlert();
   }
};
            break;
case 24:
            burn24();
			document.getElementById('audioX').onclick = function(){
   if (x1 === x2) {
  			document.getElementById('popupX').style.display = 'block'; // show
			audioIDX1.play(); 
	   anular();
   } else if (x1 !== x2){
	showAlert();
   }
};
            break;
case 25:
            burn25();			
			document.getElementById('audioY').onclick = function(){
   if (y1 === y2) {
  			document.getElementById('popupY').style.display = 'block'; // show
			audioIDY1.play(); 
	   anular();
   } else if (y1 !== y2){
	showAlert();
   }
};
            break;
case 26:
            burn26();
			document.getElementById('audioZ').onclick = function(){
   if (z1 === z2) {
  			document.getElementById('popupZ').style.display = 'block'; // show
			audioIDZ1.play(); 
	   anular();
   } else if (z1 !== z2){
	showAlert();
   }
};
            break;
    }
}