//AUDIO A

var audioA = document.getElementById("audioIDA");
function playAudioA() {
  letrasA.play();
}

var audioA1 = document.getElementById("audioIDA1");
function playAudioA1() {
  audioA1.play();
}

//AUDIO B
var audioB = document.getElementById("audioIDB");
function playAudioB() {
  audioB.play();
}

var audioB1 = document.getElementById("audioIDB1");
function playAudioB1() {
  audioB1.play();
}

//AUDIO C
var audioC = document.getElementById("audioIDC");
function playAudioC() {
  audioC.play();
}

var audioC1 = document.getElementById("audioIDC1");
function playAudioC1() {
  audioC1.play();
}

//AUDIO D
var audioD = document.getElementById("audioIDD");
function playAudioD() {
  audioD.play();
}

var audioD1 = document.getElementById("audioIDD1");
function playAudioD1() {
  audioD1.play();
}

//AUDIO E
var audioE = document.getElementById("audioIDE");
function playAudioE() {
  audioE.play();
}

var audioE1 = document.getElementById("audioIDE1");
function playAudioE1() {
  audioE1.play();
}


//AUDIO F
var audioF = document.getElementById("audioIDF");
function playAudioF() {
  audioF.play();
}

var audioF1 = document.getElementById("audioIDF1");
function playAudioF1() {
  audioF1.play();
}

//AUDIO G
var audioG = document.getElementById("audioIDG");
function playAudioG() {
  audioG.play();
}

var audioG1 = document.getElementById("audioIDG1");
function playAudioG1() {
  audioG1.play();
}



//AUDIO H
var audioH = document.getElementById("audioIDH");
function playAudioH() {
  audioH.play();
}

var audioH1 = document.getElementById("audioIDH1");
function playAudioH1() {
  audioH1.play();
}

//AUDIO I
var audioI = document.getElementById("audioIDI");
function playAudioI() {
  audioI.play();
}

var audioI1 = document.getElementById("audioIDI1");
function playAudioI1() {
  audioI1.play();
}



//AUDIO J
var audioJ = document.getElementById("audioIDJ");
function playAudioJ() {
  audioJ.play();
}

var audioJ1 = document.getElementById("audioIDJ1");
function playAudioJ1() {
  audioJ1.play();
}

//AUDIO K
var audioK = document.getElementById("audioIDK");
function playAudioK() {
  audioK.play();
}

var audioK1 = document.getElementById("audioIDK1");
function playAudioK1() {
  audioK1.play();
}



//AUDIO L
var audioL = document.getElementById("audioIDL");
function playAudioL() {
  audioL.play();
}

var audioL1 = document.getElementById("audioIDL1");
function playAudioL1() {
  audioL1.play();
}


//AUDIO M 
var audioM = document.getElementById("audioIDM");
function playAudioM() {
  audioM.play();
}

var audioM1 = document.getElementById("audioIDM1");
function playAudioM1() {
  audioM1.play();
}


//AUDIO N
var audioN = document.getElementById("audioIDN");
function playAudioN() {
  audioN.play();
}

var audioN1 = document.getElementById("audioIDN1");
function playAudioN1() {
  audioN1.play();
}

//AUDIO O
var audioO = document.getElementById("audioIDO");
function playAudioO() {
  audioO.play();
}

var audioO1 = document.getElementById("audioIDO1");
function playAudioO1() {
  audioO1.play();
}


//AUDIO P
var audioP = document.getElementById("audioIDP");
function playAudioP() {
  audioP.play();
}

var audioP1 = document.getElementById("audioIDP1");
function playAudioP1() {
  audioP1.play();
}

//AUDIO Q
var audioQ = document.getElementById("audioIDQ");
function playAudioQ() {
  audioQ.play();
}

var audioQ1 = document.getElementById("audioIDQ1");
function playAudioQ1() {
  audioQ1.play();
}

//AUDIO R
var audioR = document.getElementById("audioIDR");
function playAudioR() {
  audioR.play();
}

var audioR1 = document.getElementById("audioIDR1");
function playAudioR1() {
  audioR1.play();
}

//AUDIO S
var audioS = document.getElementById("audioIDS");
function playAudioS() {
  audioS.play();
}

var audioS1 = document.getElementById("audioIDS1");
function playAudioS1() {
  audioS1.play();
}

//AUDIO T
var audioT = document.getElementById("audioIDT");
function playAudioT() {
  audioT.play();
}

var audioT1 = document.getElementById("audioIDT1");
function playAudioT1() {
  audioT1.play();
}


//AUDIO U
var audioU = document.getElementById("audioIDU");
function playAudioU() {
  audioU.play();
}

var audioU1 = document.getElementById("audioIDU1");
function playAudioU1() {
  audioU1.play();
}


//AUDIO V
var audioV = document.getElementById("audioIDV");
function playAudioV() {
  audioV.play();
}

var audioV1 = document.getElementById("audioIDV1");
function playAudioV1() {
  audioV1.play();
}


//AUDIO W
var audioW = document.getElementById("audioIDW");
function playAudioW() {
  audioW.play();
}

var audioW1 = document.getElementById("audioIDW1");
function playAudioW1() {
  audioW1.play();
}

//AUDIO X
var audioX = document.getElementById("audioIDX");
function playAudioX() {
  audioX.play();
}

var audioX1 = document.getElementById("audioIDX1");
function playAudioX1() {
  audioX1.play();
}


//AUDIO Y
var audioY = document.getElementById("audioIDY");
function playAudioY() {
  audioY.play();
}


var audioY1 = document.getElementById("audioIDY1");
function playAudioY1() {
  audioY1.play();
}

//AUDIO Z
var audioZ = document.getElementById("audioIDZ");
function playAudioZ() {
  audioZ.play();
}

var audioZ1 = document.getElementById("audioIDZ1");
function playAudioZ1() {
  audioZ1.play();
}
