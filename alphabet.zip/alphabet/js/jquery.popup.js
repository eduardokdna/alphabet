var choice = 0;

$(function() {
  var audiosTable = {
    'audioA': audioIDA1,
    'audioB': audioIDB1,
    'audioC': audioIDC1,
    'audioD': audioIDD1,
    'audioE': audioIDE1,
    'audioF': audioIDF1,
    'audioG': audioIDG1,
    'audioH': audioIDH1,
    'audioI': audioIDI1,
    'audioJ': audioIDJ1,
    'audioK': audioIDK1,
    'audioL': audioIDL1,
    'audioM': audioIDM1,
    'audioN': audioIDN1,
    'audioO': audioIDO1,
    'audioP': audioIDP1,
    'audioQ': audioIDQ1,
    'audioR': audioIDR1,
    'audioS': audioIDS1,
    'audioT': audioIDT1,
    'audioU': audioIDU1,
    'audioV': audioIDV1,
    'audioW': audioIDW1,
    'audioX': audioIDX1,
    'audioY': audioIDY1,
    'audioZ': audioIDZ1
  },
  lettersIds = ['','audioA','audioB','audioC','audioD','audioE','audioF','audioG','audioH','audioI','audioJ','audioK','audioL','audioM','audioN','audioO','audioP','audioQ','audioR','audioS','audioT','audioU','audioV','audioW','audioX','audioY','audioZ'],
  modalIds = ['','popupA','popupB','popupC','popupD','popupE','popupF','popupG','popupH','popupI','popupJ','popupK','popupL','popupM','popupN','popupO','popupP','popupQ','popupR','popupS','popupT','popupU','popupV','popupW','popupX','popupY','popupZ'];

	//----- OPEN
	$('[data-popup-open]').on('click', function(e)  {
		var targeted_popup_class = jQuery(this).attr('data-popup-open');
		$('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
		e.preventDefault();
	});
	//----- CLOSE
	$('[data-popup-close]').on('click', function(e)  {
		var targeted_popup_class = jQuery(this).attr('data-popup-close');
		$('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
		e.preventDefault();
	});
  $('.btn-letter').on('click', function(){
    if (this.id == lettersIds[choice]) {
      audiosTable[this.id].play();
      document.getElementById(modalIds[choice]).style.display = 'block';
    } else if (choice != 0) {
      showAlert();
    }
  });
});

///////	
function burn1() {
    letras1.play();	
}
function burn2() {
   letras2.play();	  
}
function burn3() {
    letras3.play();
}
function burn4() {
    letras4.play();
}
function burn5() {
    letras5.play();
}
function burn6() {
    letras6.play();
}
function burn7() {
   letras7.play();
}
function burn8() {
    letras8.play();
}
function burn9() {
    letras9.play();
}
function burn10() {
    letras10.play();
}
function burn11() {
    letras11.play();
}
function burn12() {
   letras12.play();
}
function burn13() {
    letras13.play();
}
function burn14() {
    letras14.play();
}
function burn15() {
    letras15.play();
}
function burn16() {
    letras16.play();
}
function burn17() {
   letras17.play();
}
function burn18() {
    letras18.play();
}
function burn19() {
    letras19.play();
}
function burn20() {
    letras20.play();
}		
function burn21() {
    letras21.play();
}
function burn22() {
   letras22.play();
}
function burn23() {
    letras23.play();
}
function burn24() {
    letras24.play();
}
function burn25() {
    letras25.play();
}
function burn26() {
    letras26.play();
}		


function showAlert() {
  audioID0.play();
  alert("Oh you wrong!");
}

function random() {	
  var rand = Math.floor(Math.random() * (26 - 1)) + 1;
  choice = rand;

  switch(rand) {
    case 1:
      burn1();	
      break;
    case 2:
      burn2();
      break;
    case 3:
      burn3();
      break;
    case 4:
      burn4();
      break;
    case 5:
      burn5();
      break;
    case 6:
      burn6();
      break;
    case 7:
      burn7();
      break;
    case 8:
      burn8();
      break;
    case 9:
      burn9();
      break;
    case 10:
      burn10();
      break;
    case 11:
      burn11();
      break;
    case 12:
      burn12();
      break;
    case 13:
      burn13();
      break;
    case 14:
      burn14();
      break;
    case 15:
      burn15();
      break;
    case 16:
      burn16();
      break;
    case 17:
      burn17();
      break;
    case 18:
      burn18();
      break;
    case 19:
      burn19();
      break;
    case 20:
      burn20();
      break;
    case 21:
      burn21();
      break;
    case 22:
      burn22();
      break;
    case 23:
      burn23();
      break;
    case 24:
      burn24();
      break;
    case 25:
      burn25();			
      break;
    case 26:
      burn26();
      break;
    }
}