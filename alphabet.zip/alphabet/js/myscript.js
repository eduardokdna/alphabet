


$("button").click(showMessage);

$("#success").hide();
$("#success").css({
  width: 0,
  height: 0,
});

$('.drag').draggable({
  containment: '#content',
  stack: ".drag, .drop",
  cursor: 'move',
  revert: true
});


$('#droppable1').droppable({
  drop: handleDropEvent,
  accept: "#draggable1",
  hoverClass: "hovered"
});

$('#droppable2').droppable({
  drop: handleDropEvent,
  accept: "#draggable2",
  hoverClass: "hovered"
});

$('#droppable3').droppable({
  drop: handleDropEvent,
  accept: "#draggable3",
  hoverClass: "hovered"
});

$('#droppable4').droppable({
  drop: handleDropEvent,
  accept: "#draggable4",
  hoverClass: "hovered"
});

$('#droppable5').droppable({
  drop: handleDropEvent,
  accept: "#draggable5",
  hoverClass: "hovered"
});


$('#droppable6').droppable({
  drop: handleDropEvent,
  accept: "#draggable6",
  hoverClass: "hovered"
});

$('#droppable7').droppable({
  drop: handleDropEvent,
  accept: "#draggable7",
  hoverClass: "hovered"
});

$('#droppable8').droppable({
  drop: handleDropEvent,
  accept: "#draggable8",
  hoverClass: "hovered"
});

$('#droppable9').droppable({
  drop: handleDropEvent,
  accept: "#draggable9",
  hoverClass: "hovered"
});




var food = 9;
var droppedFood = 0;


function handleDropEvent(event, ui){	
	ui.draggable.addClass('dragging')
ui.draggable.draggable('disable');
  
  ui.draggable.draggable('option', 'revert', false);
  droppedFood += 1;
  if(droppedFood === food){
    console.log("Game Over!");
    showMessage();
  }
}

function showMessage(){
	$("#audio-0")[0].play();
  $("#success").show();
  $("#success").animate({
    width: "50%",
    height: "300px",
	  margin: "auto",  
    top: "100px",
    left: "240px",
    opacity: 1
  });
	
}



$(function() {
        $("#draggable1").draggable({
          start: function() {
            $("#audio-drag1")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable2").draggable({
          start: function() {
            $("#audio-drag2")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable3").draggable({
          start: function() {
            $("#audio-drag3")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable4").draggable({
          start: function() {
            $("#audio-drag4")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable5").draggable({
          start: function() {
            $("#audio-drag5")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable6").draggable({
          start: function() {
            $("#audio-drag6")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable7").draggable({
          start: function() {
            $("#audio-drag7")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable8").draggable({
          start: function() {
            $("#audio-drag8")[0].play();
          }
        });        
      });

$(function() {
        $("#draggable9").draggable({
          start: function() {
            $("#audio-drag9")[0].play();
          }
        });        
      });

